package com.example.sqllite181103507;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.database.sqlite.SQLiteException;
import android.icu.text.CaseMap;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText firstname, lastname;
    TextView textView;
    dbcontroler controller;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        firstname = findViewById(R.id.editfrstname);
        lastname = findViewById(R.id.editlastname);
        textView= findViewById(R.id.textview);

                controller = new dbcontroler(this, "", null, 1);
    }
    public void btn_click(View view) {
        AlertDialog.Builder dialog = null;
        switch (view.getId()) {
            case R.id.btn_add:
                try {
                    controller.insert_student(firstname.getText().toString(), lastname.getText().toString());

                } catch (SQLiteException e) {
                    Toast.makeText(MainActivity.this, "ALREADY EXIST", Toast.LENGTH_LONG).show();

                }
                break;
            case R.id.btn_Delet:
                controller.delete_student(firstname.getText().toString());
                break;
            case R.id.btn_list:
                controller.list_all_student(textView);
                break;
            case R.id.btn_update:

                dialog = new AlertDialog.Builder(MainActivity.this);
                dialog.setTitle("Masukan Nama");

                final EditText newFirshName = new EditText(this);
                dialog.setView(newFirshName);

                dialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        controller.update_student(firstname.getText().toString(),newFirshName.getText().toString());
                    }

        });
        dialog.show();
        break;

    }
}
}
